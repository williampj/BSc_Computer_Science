import csv

# CSVReader class constitutes the interface to all CSV files used by the program
class CSVReader:
    # Loads all csv files into instance variables for easy reference
    def __init__(self):
        with open('./csv/Address.csv') as address_csv:
            self.addresses = list(csv.reader(address_csv))

        with open('./csv/Distance.csv') as distance_csv:
            self.distances = list(csv.reader(distance_csv))

        with open('./csv/Package.csv') as package_csv:
            next(package_csv)  # skips first line of headers
            self.packages = list(csv.reader(package_csv))

    # Retrieves the address id for any given address for use by the find_distance_between method
    # Time: O(N) - linear search through self.addresses
    def get_address_id(self, address):
        for address_line in self.addresses:
            if address in address_line[2]:
                return int(address_line[0])

    # Return the distance in miles between two locations. Addresses are bidirectional but only listed in one direction
    # in the CSV file, so the opposite direction is looked up in case the first lookup is empty
    def find_distance_between(self, location_id, destination_id):
        return float(self.distances[location_id][destination_id] or self.distances[destination_id][location_id])
