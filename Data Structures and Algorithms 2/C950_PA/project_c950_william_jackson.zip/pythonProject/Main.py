# William Jackson
# Student ID: 002982231

# The four dependencies of the program
from CSVReader import CSVReader
from HashTable import HashTable
from Package import Package
from Truck import Truck

from datetime import timedelta

PROGRAM_NAME = "WGUPS Routing Program"

# Truck one will be loaded with packages with the earliest deadlines in the day plus other packages at same addresses
TRUCK_ONE_PACKAGE_IDS = [1, 7, 8, 13, 14, 15, 16, 20, 21, 29, 30, 31, 34, 37, 39, 40]
TRUCK_TWO_PACKAGE_IDS = [3, 5, 6, 18, 25, 26, 27, 28, 32, 35, 36, 38]
TRUCK_THREE_PACKAGE_IDS = [2, 4, 9, 10, 11, 12, 17, 19, 22, 23, 24, 33]  # All packages for truck three have EOD deadlines
TRUCKS_PACKAGE_IDS = [TRUCK_ONE_PACKAGE_IDS, TRUCK_TWO_PACKAGE_IDS, TRUCK_THREE_PACKAGE_IDS]

# truck one will leave at the earliest time possible of 8 AM
# truck two will leave at 9:05 AM at which time several new packages will be ready for delivery
# Truck three will depart at 10:20 AM at which time the address for all remaining packages will be known
# The prerequisite for leaving at 10:20 AM is that the driver of truck one has returned at this time in order to drive truck three
TRUCK_ONE_DEPARTURE_TIME = timedelta(hours=8, minutes=0)
TRUCK_TWO_DEPARTURE_TIME = timedelta(hours=9, minutes=5)
TRUCK_THREE_DEPARTURE_TIME = timedelta(hours=10, minutes=20)
TRUCKS_DEPARTURE_TIMES = [TRUCK_ONE_DEPARTURE_TIME, TRUCK_TWO_DEPARTURE_TIME, TRUCK_THREE_DEPARTURE_TIME]


# Instantiates all trucks with their respective departure times
# Time: O(N) - iterates through trucks and their departure times
# Space: S(N) - creates a new truck instance for each truck
def instantiate_trucks_():
    trucks = []
    for index, truck_departure in enumerate(TRUCKS_DEPARTURE_TIMES):
        trucks.append(Truck(index + 1, truck_departure))
    return trucks

# The main program to be called from the terminal
class Main:
    def __init__(self):
        self.csv_reader = CSVReader()
        self.package_table = HashTable()
        self.trucks = instantiate_trucks_()

    # Loads the hash table with Package instances based on the accompanying Package.csv file
    # Time: O(N) - iterates through all package numbers
    # Space: S(N) - creates a new Package instance for each package number in the list
    def __load_package_table_(self):
        # package indices: 0=ID, 1=address, 2=city, 3=state, 4=deadline, 5=zip, 6=weight, 7=notes
        for package in self.csv_reader.packages:
            instantiated_package = Package(int(package[0]), package[1], package[2], package[3],
                                               package[4], package[5], package[6], package[7])
            self.package_table.insert(instantiated_package.ID, instantiated_package)

    # Runs the user interface that allows user to query status for one or all packages at a selected time
    # User interface consists of an outer loop and three inner loops (one for each input type)
    def __run_user_interface_(self):
        print("Total miles driven: " + str(round(self.trucks[0].miles_driven + self.trucks[1].miles_driven +
                                                 self.trucks[2].miles_driven, 2)))
        print(f'\n{PROGRAM_NAME}')

        while True:
            try:
                while True:
                    answer = input("\nWould you like to query the status or one or more packages? "
                                   "Please enter 'Y' for yes or 'N' to quit\n").lower()
                    if answer == 'n':  # if user wishes to quit program
                        print("Thank you for using the WGUPS Routing Program")
                        return
                    elif answer == 'y':  # continues to query part of the program
                        break
                    else:
                        print("Sorry, that was not a valid answer")

                while True:
                    package_id = input("\nPlease select a package id between 1 and 40 to query, or enter '0' "
                                       "to query all packages\n")
                    package_id = int(package_id)
                    if 0 <= package_id <= 40:  # currently 40 packages in the program with '0' the option to display all
                        break
                    print("Sorry, that was not a valid package id answer\n")

                while True:
                    time_input = input("\nPlease enter a time in the format HH:MM\n")
                    [hours, minutes] = time_input.split(":")
                    am_pm = input("\nPlease enter 'a' for 'AM' or 'p' for 'PM\n").lower()
                    minutes = int(minutes)
                    hours = int(hours)
                    invalid_formats = []  # gathers invalid user input
                    if not 0 <= hours <= 12:
                        invalid_formats.append(f'hours: {hours}')
                    if not 0 <= minutes <= 59:
                        invalid_formats.append(f'minutes: {minutes}')
                    if am_pm not in ['a', 'p']:
                        invalid_formats.append(f'AM/PM: {am_pm}')
                    if not len(invalid_formats):
                        break  # continues program if all inputs were valid
                    print("\nSorry, the following entries were invalid:")
                    for invalid_format in invalid_formats:
                        print(invalid_format)  # displays which entered selections were invalid

                hours = (hours if am_pm == 'a' else hours + 12)  # converts hours to 24-hour format for timedelta use
                if package_id == 0:  # user selected to query all packages
                    for package_id in range(1, 41):
                        package = self.package_table.search(package_id)
                        status = package.status_at_time(timedelta(hours=hours, minutes=minutes))
                        print(f'Package {package_id} was {status}')
                else:  # user queried a specific package
                    package = self.package_table.search(package_id)
                    status = package.status_at_time(timedelta(hours=hours, minutes=minutes))
                    print(f'\nPackage {package_id} was {status}')
            except ValueError:
                print("Invalid entry")  # Gathers all other input errors

    # Orchestration method that coordinates the program
    def run(self):
        self.__load_package_table_()  # O(N)
        # At the time of departure (10:20 AM) of Truck 3, the correct address for package 9 is known and updated
        Package.update_package_destination(9, "410 S State St", "Salt Lake City", "UT", "84111", self.package_table)

        for truck_index, truck in enumerate(self.trucks):
            # Iterates the truck collection and loads each truck with the manually assigned package numbers
            truck.load(TRUCKS_PACKAGE_IDS[truck_index], self.package_table)  # O(N), S(N)
            # Orders truck packages using a nearest neighbor algorithm
            truck.order_packages(self.csv_reader)  # O(N^2), S(N)
            # Executes the delivery of all packages
            truck.deliver_packages(self.csv_reader)  # O(N)
            print(truck)  # prints the summary for each truck

        self.__run_user_interface_()  # User interface is displayed after all packages have been delivered


Main().run()
