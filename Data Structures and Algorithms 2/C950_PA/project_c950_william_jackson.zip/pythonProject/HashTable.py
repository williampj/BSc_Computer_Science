# Source:
# C950 - Webinar-1 - Let’s Go Hashing

# HashTable class using chaining.
class HashTable:
    def __init__(self, initial_capacity=30):
        self.table = [[] for _ in range(initial_capacity)]

    # Private method to retrieve bucket
    def __get_bucket(self, key):
        bucket = hash(key) % len(self.table)
        return self.table[bucket]

    # Private method to retrieve key_value in bucket
    def __find_key_value_in_bucket(self, bucket_list, key):
        for key_value in bucket_list:
            if key_value[0] == key:
                return key_value
        return False

    # Inserts a new item into the hash table.
    # Time: O(1)
    def insert(self, key, item):
        bucket_list = self.__get_bucket(key)
        matching_key_value = self.__find_key_value_in_bucket(bucket_list, key)

        if matching_key_value is False:
            # Add key if not present in hash table
            key_value = [key, item]
            bucket_list.append(key_value)
        else:
            # update key if it is already in the bucket
            matching_key_value[1] = item
        return True

    # Searches for an item with matching key in the hash table.
    # Returns the item if found, or None if not found.
    # Time: O(1)
    def search(self, key):
        bucket_list = self.__get_bucket(key)
        matching_key_value = self.__find_key_value_in_bucket(bucket_list, key)

        if matching_key_value is False:
            return None

        return matching_key_value[1]  # value

    # Removes item with matching key from the hash table if present
    # Time: O(1)
    def remove(self, key):
        bucket_list = self.__get_bucket(key)
        matching_key_value = self.__find_key_value_in_bucket(bucket_list, key)

        if matching_key_value is not False:
            bucket_list.remove([matching_key_value[0], matching_key_value[1]])