from datetime import *


# utility method that convert 24-hour format to AM/PM format for the user
def convert_to_am_pm(timedelta_object):
    datetime_object = datetime.strptime(str(timedelta_object), '%H:%M:%S')
    return datetime_object.strftime('%I:%M %p')


# Package class allows package information to be encapsulated in instantiated packages
class Package:
    def __init__(self, ID, address, city, state, zip, deadline,  weight, notes, delivery_status='At the hub'):
        self.ID = ID
        self.address = address
        self.city = city
        self.state = state
        self.deadline = deadline
        self.zip = zip
        self.weight = weight
        self.notes = notes
        self.delivery_status = delivery_status
        self.departure_time = None
        self.loaded_time = None
        self.truck = None
        self.delivery_time = None

    # Returns string of package used for debugging purposes
    def __str__(self):
        return (f'Package ID: {self.ID}, Deadline: {self.deadline}, Weight: {self.weight}, '
                f'Address: {self.address}, City: {self.city}, State: {self.state}, Zip: {self.zip}, '
                f'Delivery Status: {self.delivery_status}, Delivery Time: {self.delivery_time}, '
                f'Departure time: {self.departure_time}, Truck: {self.truck}, Notes: {self.notes}')

    # Static method that updates the destination of a package given the id and the package table
    @staticmethod
    def update_package_destination(package_id, address, city, state, zip, package_table):
        package = package_table.search(package_id)  # retrieves package from hash table
        package.address = address
        package.city = city
        package.state = state
        package.zip = zip

    # status method used by the user interface to gather that status of a package at a given time
    def status_at_time(self, input_time):
        if input_time > self.delivery_time:  # delivered if input time is later than delivery time
            return (f'{self.delivery_status} to {self.address}, {self.city}, {self.state} '
                    f'at {convert_to_am_pm(self.delivery_time)} by {self.truck}')
        elif input_time >= self.departure_time:  # en route if input time is later than departure time
            return f'en route on {self.truck} at {convert_to_am_pm(input_time)} '
        else:  # otherwise the package was still at the hub at entered input time
            return f'still at the hub at {convert_to_am_pm(input_time)}'




