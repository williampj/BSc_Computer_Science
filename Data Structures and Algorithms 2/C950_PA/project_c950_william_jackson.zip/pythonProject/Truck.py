from math import ceil
from datetime import datetime, timedelta

BASE_ADDRESS = "4001 South 700 East"  # hub address of the WGUPS Routing Program
DRIVING_SPEED = 0.3  # miles per minute (equivalent to 18 miles per hour)


# Converts time from 24-hour format to AM/PM format for user interface
def convert_to_am_pm(timedelta_object):
    datetime_object = datetime.strptime(str(timedelta_object), '%H:%M:%S')
    return datetime_object.strftime('%I:%M %p')


# Calculates distance and travel time between two locations
# Time: O(1)
# Space: S(1)
def get_distance_and_travel_time(current_location, destination, csv_reader):
    current_address_id = csv_reader.get_address_id(current_location)
    package_address_id = csv_reader.get_address_id(destination)
    distance_to_destination = csv_reader.find_distance_between(current_address_id, package_address_id)
    travel_time_to_destination = ceil(distance_to_destination / DRIVING_SPEED)  # rounds up to nearest minute
    return [distance_to_destination, travel_time_to_destination]


# Truck class encapsulates all truck data and behavior
class Truck:
    def __init__(self, truck_id, current_time):
        self.truck_ID = "Truck " + str(truck_id)
        self.current_time = current_time
        self.departure_time = current_time
        self.miles_driven = 0
        self.location = BASE_ADDRESS
        self.completion_time = None
        self.remaining_packages = []
        self.delivered_packages = []

    # Returns string information used for print statement summarizing the performance of each truck
    def __str__(self):
        return (f'{self.truck_ID}, Number of packages delivered: {len(self.delivered_packages)}, '
                f'miles driven: {round(self.miles_driven, 3)}, '
                f'Departure time: {convert_to_am_pm(self.departure_time)}, '
                f'Completion_time: {convert_to_am_pm(self.completion_time)}')

    # Maps each package number to its package object in the hash table and assigns them to the remaining_packages list
    # Time: O(N) - iterates through package numbers, and performs an O(1) package_table.search for each
    # Space: S(1) - No added memory used since the packages are already instantiated and referenced
    def load(self, package_numbers, package_table):
        self.remaining_packages = list(map(lambda package_number: package_table.search(package_number), package_numbers))

    # Orders the packages using a greedy, nearest-neighbor algorithm
    # Time: O(N^2) - nested loop of remaining_packages
    # Space: S(N) - An ordered_packages list is used to store the new ordering of packages
    def order_packages(self, csv_reader):
        ordered_packages = []
        current_address = self.location
        distance_to_pending_next_address = float('inf')   # ensures first package will be set as pending destination
        pending_next_package = None

        while len(self.remaining_packages):
            # Finds the nearest package destination
            current_address_id = csv_reader.get_address_id(current_address)
            for package in self.remaining_packages:
                package_address_id = csv_reader.get_address_id(package.address)
                distance_to_package_address = csv_reader.find_distance_between(current_address_id, package_address_id)
                # Keeps trak of nearest package
                if distance_to_package_address < distance_to_pending_next_address:
                    distance_to_pending_next_address = distance_to_package_address
                    pending_next_package = package
            # Adds package with nearest destination and removes it from remaining packages list
            ordered_packages.append(pending_next_package)
            self.remaining_packages.remove(pending_next_package)
            current_address = pending_next_package.address
            pending_next_package = None
            distance_to_pending_next_address = float('inf')

        self.remaining_packages = ordered_packages  # remaining_packages is now ordered according to delivery schedule

    # Implements the delivery of all packages
    def deliver_packages(self, csv_reader):
        # Updates package delivery status, truck and departure time when truck departs
        for package in self.remaining_packages:
            package.delivery_status = "En Route"  # package status until delivered
            package.truck = self.truck_ID
            package.departure_time = self.current_time

        for package in self.remaining_packages:
            # Determines time and distance to next location
            [distance_to_next_address, travel_time_to_next_address] = (
                get_distance_and_travel_time(self.location, package.address, csv_reader))

            # Updates truck status after each delivery
            self.current_time += timedelta(minutes=travel_time_to_next_address)
            self.miles_driven += distance_to_next_address
            self.delivered_packages.append(package)
            self.location = package.address

            # Updates delivered package status after delivery
            package.delivery_time = self.current_time
            package.delivery_status = "delivered"

        self.remaining_packages.clear()  # all packages have been delivered

        # Time and distance to the base address
        [distance_to_base, travel_time_to_base] = get_distance_and_travel_time(self.location, BASE_ADDRESS, csv_reader)

        # Final truck update after having returned to the base address
        self.current_time += timedelta(minutes=travel_time_to_base)
        self.miles_driven += distance_to_base
        self.location = BASE_ADDRESS
        self.completion_time = self.current_time
