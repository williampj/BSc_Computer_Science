#ifndef degree_h
#define degree_h

enum DegreeProgram
{
  SECURITY,
  NETWORK,
  SOFTWARE
};

#endif